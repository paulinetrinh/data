###############################################
# 
# Setup
#
###############################################

utils::download.file("LINK", "STAMPS2018_R.zip")
utils::unzip("STAMPS2018_R.zip")
